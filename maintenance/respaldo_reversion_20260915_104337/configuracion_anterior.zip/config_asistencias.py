ASISTENCIAS_CONFIG = {
    "host": "",
    "puerto": 3306,
    "usuario": "",
    "password": "",
    "base_datos": "",
    "tabla_asistencias": "asistencias",
    "columna_dispositivo": "dispositivo_id",
    "columna_empleado": "empleado_id",
    "columna_fecha_hora": "fecha_hora",
    "columna_tipo_evento": "tipo_evento",
    "columna_metodo": "metodo",
}
