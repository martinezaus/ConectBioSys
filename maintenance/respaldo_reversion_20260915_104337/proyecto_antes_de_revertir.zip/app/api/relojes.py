import datetime
from app.trabajos import ControladorTrabajo
from app.servicios import limpiar_reloj
from app.perfiles import ruta_marcaciones
from resources.config_path import guardar_relojes, probar_conexion

from PyQt6.QtWidgets import (
	QWidget,
	QVBoxLayout,
	QPushButton,
	QHBoxLayout,
	QMessageBox,
	QLineEdit,
	QDialog,
	QDialogButtonBox,
	QTableWidget,
	QTableWidgetItem,
	QCheckBox,
	QLabel,
	QComboBox,
	QFormLayout,
	QInputDialog,
	QApplication,
	QDateEdit,
)

from PyQt6.QtCore import QDate

from resources.config_path import (
	cargar_config_conexion,
	guardar_config_conexion,
	crear_engine_externo,
	cargar_config_empleados,
	guardar_config_empleados,
	cargar_config_asistencias,
	guardar_config_asistencias,
	cargar_relojes,
	crear_adaptador,
)
from resources.db_engines import ENGINES
from app.perfiles import integracion_habilitada
from app.licencias import exigir_licencia

# Campos que necesita cada tipo de reloj: (nombre, tipo_de_dato, valor_por_defecto)
# Si agregás un adaptador nuevo, sumalo acá y el formulario lo va a mostrar solo.
CAMPOS_POR_TIPO = {
	"zkteco": [
		("ip", str, ""),
		("dispositivo_id", str, ""),
		("puerto", int, 4370),
		("force_udp", bool, False),
		("comm_key", int, 0),
		("timeout", int, 15),
	],
	"hikvision": [
		("ip", str, ""),
		("dispositivo_id", str, ""),
		("puerto", int, 80),
		("timeout", int, 15),
		("usuario", str, "admin"),
		("password", str, ""),
		("usar_https", bool, False),
	],
}

class RelojFormDialog(QDialog):
	"""Formulario para dar de alta o editar un reloj. Los campos que se
	muestran dependen del tipo elegido (ver CAMPOS_POR_TIPO)."""

	def __init__(self, reloj=None, parent=None):
		super().__init__(parent)
		self.setWindowTitle("Reloj biométrico")
		self.resize(400, 250)
		self._campos_widgets = {}
		self._reloj_resultado = None

		layout = QVBoxLayout(self)

		fila_tipo = QHBoxLayout()
		fila_tipo.addWidget(QLabel("Tipo de reloj:"))
		self.combo_tipo = QComboBox()
		self.combo_tipo.addItems(list(CAMPOS_POR_TIPO.keys()))
		fila_tipo.addWidget(self.combo_tipo)
		layout.addLayout(fila_tipo)
		self.campo_modelo=QLineEdit((reloj or {}).get("modelo",""))
		self.campo_modelo.setPlaceholderText("Modelo del reloj (opcional)")
		layout.addWidget(self.campo_modelo)

		self.formulario_widget = QWidget()
		self.formulario_layout = QFormLayout()
		self.formulario_widget.setLayout(self.formulario_layout)
		layout.addWidget(self.formulario_widget)

		self.combo_tipo.currentTextChanged.connect(self._reconstruir_formulario)

		botones = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
		botones.accepted.connect(self._confirmar)
		botones.rejected.connect(self.reject)
		layout.addWidget(botones)

		if reloj:
			self.combo_tipo.setCurrentText(reloj["tipo"])
			self._reconstruir_formulario(reloj["tipo"], valores_iniciales=reloj["params"])
		else:
			self._reconstruir_formulario(self.combo_tipo.currentText())

	def _reconstruir_formulario(self, tipo, valores_iniciales=None):
		while self.formulario_layout.rowCount():
			self.formulario_layout.removeRow(0)
		self._campos_widgets = {}

		valores_iniciales = valores_iniciales or {}
		for nombre, tipo_dato, valor_por_defecto in CAMPOS_POR_TIPO[tipo]:
			valor = valores_iniciales.get(nombre, valor_por_defecto)
			if tipo_dato is bool:
				widget = QCheckBox()
				widget.setChecked(bool(valor))
			else:
				widget = QLineEdit()
				widget.setText(str(valor) if valor is not None else "")
				if nombre in ("password", "comm_key"): widget.setEchoMode(QLineEdit.EchoMode.Password)
			self.formulario_layout.addRow(nombre, widget)
			self._campos_widgets[nombre] = (widget, tipo_dato)

	def _confirmar(self):
		tipo = self.combo_tipo.currentText()
		params = {}
		for nombre, (widget, tipo_dato) in self._campos_widgets.items():
			if tipo_dato is bool:
				params[nombre] = widget.isChecked()
			elif tipo_dato is int:
				texto = widget.text() if nombre == "password" else widget.text().strip()
				if not texto.isdigit():
					QMessageBox.warning(self, "Dato inválido", f"'{nombre}' tiene que ser un número.")
					return
				params[nombre] = int(texto)
			else:
				texto = widget.text() if nombre == "password" else widget.text().strip()
				if not texto and nombre in ("ip", "dispositivo_id"):
					QMessageBox.warning(self, "Dato requerido", f"'{nombre}' es obligatorio.")
					return
				params[nombre] = texto

		if not 1<=params.get("puerto",80)<=65535 or params.get("timeout",15)<1:
			QMessageBox.warning(self,"Parámetros","Indicá un puerto de 1 a 65535 y un timeout positivo."); return
		self._reloj_resultado = {"tipo": tipo, "modelo":self.campo_modelo.text().strip(), "params": params}
		self.accept()

	def obtener_reloj(self):
		return self._reloj_resultado

class ConfiguracionRelojesDialog(QDialog):
	"""Pantalla para administrar la lista de relojes: agregar, editar,
	eliminar y guardar los cambios en resources/config_relojes.py."""

	def __init__(self, parent=None):
		super().__init__(parent)
		self.setWindowTitle("Configuración de relojes biométricos")
		self.resize(650, 400)
		self.relojes = self._cargar_relojes_actuales()

		layout = QVBoxLayout(self)
		layout.addWidget(QLabel("Relojes configurados. Agregá, editá o eliminá los que necesites."))

		self.tabla = QTableWidget()
		self.tabla.setColumnCount(4)
		self.tabla.setHorizontalHeaderLabels(["Tipo", "ID dispositivo", "IP", "Otros parámetros"])
		self.tabla.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
		self.tabla.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
		layout.addWidget(self.tabla)
		self._refrescar_tabla()

		fila_botones = QHBoxLayout()
		self.boton_agregar = QPushButton("Agregar reloj")
		self.boton_editar = QPushButton("Editar")
		self.boton_eliminar = QPushButton("Eliminar")
		self.boton_limpiar_buffer = QPushButton("Limpiar buffer")

		fila_botones.addWidget(self.boton_agregar)
		fila_botones.addWidget(self.boton_editar)
		fila_botones.addWidget(self.boton_eliminar)
		fila_botones.addWidget(self.boton_limpiar_buffer)
		fila_botones.addStretch()
		layout.addLayout(fila_botones)

		self.boton_agregar.clicked.connect(self._agregar)
		self.boton_editar.clicked.connect(self._editar)
		self.boton_eliminar.clicked.connect(self._eliminar)
		self.boton_limpiar_buffer.clicked.connect(self.limpiar_buffer_relojes)
		self.boton_limpiar_buffer.setStyleSheet(
			"QPushButton { background-color: #c0392b; color: white; font-weight: bold; }"
			"QPushButton:hover { background-color: #a93226; }"
			"QPushButton:disabled { background-color: #7f8c8d; color: #dcdcdc; }"
		)

		self.boton_config_conexion = QPushButton("Configurar conexión a base de datos")
		self.boton_config_tabla_empleados = QPushButton("Configurar tabla de empleados")
		self.boton_config_tabla_asistencias = QPushButton("Configurar tabla de asistencias")
		layout.addWidget(self.boton_config_conexion)
		layout.addWidget(self.boton_config_tabla_empleados)
		layout.addWidget(self.boton_config_tabla_asistencias)
		for boton in (self.boton_config_conexion, self.boton_config_tabla_empleados, self.boton_config_tabla_asistencias):
			boton.setVisible(integracion_habilitada())

		self.boton_config_conexion.clicked.connect(self._abrir_config_conexion)
		self.boton_config_tabla_empleados.clicked.connect(self._abrir_config_tabla_empleados)
		self.boton_config_tabla_asistencias.clicked.connect(self._abrir_config_tabla_asistencias)

	def _cargar_relojes_actuales(self):
		try:
			return [dict(tipo=r["tipo"], modelo=r.get("modelo",""), params=dict(r["params"])) for r in cargar_relojes()]
		except Exception as exc:
			raise ValueError("No se pudo leer la configuración de relojes; se conserva el contenido original.") from exc

	def _refrescar_tabla(self):
		self.tabla.setRowCount(len(self.relojes))
		for fila_idx, reloj in enumerate(self.relojes):
			params = reloj["params"]
			otros = ", ".join(
				f"{clave}={valor}" for clave, valor in params.items()
				if clave not in ("ip", "dispositivo_id", "password", "comm_key")
			)
			self.tabla.setItem(fila_idx, 0, QTableWidgetItem(reloj["tipo"]))
			self.tabla.setItem(fila_idx, 1, QTableWidgetItem(str(params.get("dispositivo_id", ""))))
			self.tabla.setItem(fila_idx, 2, QTableWidgetItem(str(params.get("ip", ""))))
			self.tabla.setItem(fila_idx, 3, QTableWidgetItem(otros))
		self.tabla.resizeColumnsToContents()

	def _agregar(self):
		dialogo = RelojFormDialog(parent=self)
		if dialogo.exec() == QDialog.DialogCode.Accepted:
			self.relojes.append(dialogo.obtener_reloj())
			if self._guardar():
				self._refrescar_tabla()
			else:
				self.relojes.pop()

	def _editar(self):
		fila = self.tabla.currentRow()
		if fila < 0:
			QMessageBox.information(self, "Editar", "Seleccioná un reloj de la lista.")
			return
		reloj_anterior = self.relojes[fila]
		dialogo = RelojFormDialog(reloj=reloj_anterior, parent=self)
		if dialogo.exec() == QDialog.DialogCode.Accepted:
			self.relojes[fila] = dialogo.obtener_reloj()
			if self._guardar():
				self._refrescar_tabla()
			else:
				self.relojes[fila] = reloj_anterior

	def _eliminar(self):
		fila = self.tabla.currentRow()
		if fila < 0:
			QMessageBox.information(self, "Eliminar", "Seleccioná un reloj de la lista.")
			return
		reloj = self.relojes[fila]
		resp = QMessageBox.question(
			self, "Eliminar reloj",
			f"¿Eliminar el reloj {reloj['params'].get('dispositivo_id', '?')}?"
		)
		if resp == QMessageBox.StandardButton.Yes:
			del self.relojes[fila]
			if self._guardar():
				self._refrescar_tabla()
			else:
				self.relojes.insert(fila, reloj)

	def _guardar(self):
		if not self.relojes:
			resp = QMessageBox.question(
				self, "Guardar sin relojes",
				"No hay relojes configurados. ¿Guardar igual una lista vacía?"
			)
			if resp != QMessageBox.StandardButton.Yes:
				return

		ids = [reloj["params"].get("dispositivo_id") for reloj in self.relojes]
		if len(ids) != len(set(ids)):
			QMessageBox.warning(
				self, "IDs repetidos",
				"Hay dos o más relojes con el mismo 'ID dispositivo'. Corregilo antes de guardar."
			)
			return

		try:
			guardar_relojes(self.relojes)
		except Exception as e:
			QMessageBox.critical(self, "Error al guardar", f"No se pudo guardar la configuración:\n{e}")
			return

		return True

	def closeEvent(self, event):
		"""Cada alta/edición/baja se guarda al toque, así que no hay cambios
		pendientes que se puedan perder al cerrar: se cierra directamente."""
		if hasattr(self,"trabajo") and self.trabajo.esta_ocupado():
			event.ignore(); return
		self.accept()
		event.accept()

	def limpiar_buffer_relojes(self):
		fila=self.tabla.currentRow()
		if fila<0:
			QMessageBox.information(self,'Limpiar buffer','Seleccioná el reloj que querés limpiar.'); return
		config=self.relojes[fila]
		if config['tipo']!='zkteco':
			QMessageBox.information(self,'No disponible','Este adaptador no ofrece una limpieza compatible. Usá la herramienta del fabricante.'); return
		try: exigir_licencia()
		except Exception as exc:
			QMessageBox.warning(self,'Licencia',str(exc)); return
		params=config['params']
		if QMessageBox.question(self,'Limpiar buffer',
			f"¿Borrar las marcaciones del reloj {params['dispositivo_id']} ({params['ip']})? Se respaldarán en SQLite antes de borrar. No elimina personas ni huellas.",
			QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes: return
		ruta=ruta_marcaciones()
		self.trabajo=ControladorTrabajo(self)
		self.trabajo.ocupado.connect(self._estado_limpieza)
		self.trabajo.error.connect(lambda mensaje: QMessageBox.warning(self,'Limpieza',mensaje))
		self.trabajo.resultado.connect(lambda mensaje: QMessageBox.information(self,'Limpieza',mensaje))
		self.trabajo.iniciar(lambda p,c:limpiar_reloj(config,ruta,p,c))
	def _estado_limpieza(self, ocupado):
		for boton in (self.boton_agregar,self.boton_editar,self.boton_eliminar,self.boton_limpiar_buffer,
			self.boton_config_conexion,self.boton_config_tabla_empleados,self.boton_config_tabla_asistencias):
			boton.setEnabled(not ocupado)
	def reject(self):
		if hasattr(self,'trabajo') and self.trabajo.esta_ocupado(): return
		super().reject()
	def _abrir_config_conexion(self):
		ConfiguracionConexionDialog(parent=self).exec()

	def _abrir_config_tabla_empleados(self):
		ConfiguracionTablaEmpleadosDialog(parent=self).exec()

	def _abrir_config_tabla_asistencias(self):
		ConfiguracionTablaAsistenciasDialog(parent=self).exec()

class RangoFechasDialog(QDialog):
	"""Pide un rango 'desde'/'hasta' antes de exportar, para no traer
	todo el histórico de una sola vez."""

	def __init__(self, parent=None):
		super().__init__(parent)
		self.setWindowTitle("Elegir rango de fechas")

		layout = QVBoxLayout(self)
		layout.addWidget(QLabel("Elegí el rango de marcaciones a exportar:"))

		form = QFormLayout()
		hoy = QDate.currentDate()

		self.fecha_desde = QDateEdit(calendarPopup=True)
		self.fecha_desde.setDisplayFormat("yyyy-MM-dd")
		self.fecha_desde.setDate(hoy.addMonths(-1))

		self.fecha_hasta = QDateEdit(calendarPopup=True)
		self.fecha_hasta.setDisplayFormat("yyyy-MM-dd")
		self.fecha_hasta.setDate(hoy)

		form.addRow("Desde:", self.fecha_desde)
		form.addRow("Hasta:", self.fecha_hasta)
		layout.addLayout(form)

		botones = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
		botones.accepted.connect(self._validar)
		botones.rejected.connect(self.reject)
		layout.addWidget(botones)

	def _validar(self):
		if self.fecha_desde.date() > self.fecha_hasta.date():
			QMessageBox.warning(self, "Rango inválido", "'Desde' no puede ser posterior a 'Hasta'.")
			return
		self.accept()

	def obtener_rango(self):
		return (
			self.fecha_desde.date().toString("yyyy-MM-dd"),
			self.fecha_hasta.date().toString("yyyy-MM-dd"),
		)	

class ConfiguracionConexionDialog(QDialog):
	"""Elige el motor de base de datos y sus datos de conexión. Esta config
	es compartida entre la lectura de empleados y el envío de asistencias."""

	def __init__(self, parent=None):
		super().__init__(parent)
		self.setWindowTitle("Configurar conexión a base de datos")
		self.resize(420, 320)

		config_actual = cargar_config_conexion()

		layout = QVBoxLayout(self)
		form = QFormLayout()

		self.combo_motor = QComboBox()
		for clave, info in ENGINES.items():
			self.combo_motor.addItem(info["label"], clave)
		idx = self.combo_motor.findData(config_actual.get("motor", "mysql"))
		if idx >= 0:
			self.combo_motor.setCurrentIndex(idx)
		form.addRow("Motor:", self.combo_motor)

		self.campo_host = QLineEdit(config_actual.get("host", ""))
		self.campo_puerto = QLineEdit(str(config_actual.get("puerto") or ""))
		self.campo_usuario = QLineEdit(config_actual.get("usuario", ""))
		self.campo_password = QLineEdit(config_actual.get("password", ""))
		self.campo_password.setEchoMode(QLineEdit.EchoMode.Password)
		self.campo_base_datos = QLineEdit(config_actual.get("base_datos", ""))
		self.campo_archivo_sqlite = QLineEdit(config_actual.get("archivo_sqlite", ""))
		self.campo_driver_odbc = QLineEdit(config_actual.get("driver_odbc", "ODBC Driver 18 for SQL Server"))
		form.addRow("Driver ODBC (SQL Server):", self.campo_driver_odbc)

		self.fila_host = form.addRow("Host / IP:", self.campo_host)
		self.fila_puerto = form.addRow("Puerto:", self.campo_puerto)
		self.fila_usuario = form.addRow("Usuario:", self.campo_usuario)
		self.fila_password = form.addRow("Contraseña:", self.campo_password)
		self.fila_base_datos = form.addRow("Base de datos / servicio Oracle:", self.campo_base_datos)
		self.fila_archivo = form.addRow("Archivo SQLite:", self.campo_archivo_sqlite)

		layout.addLayout(form)

		self.combo_motor.currentIndexChanged.connect(self._actualizar_campos_visibles)
		self._actualizar_campos_visibles()

		fila_botones = QHBoxLayout()
		self.boton_probar = QPushButton("Probar conexión")
		fila_botones.addWidget(self.boton_probar)
		fila_botones.addStretch()
		layout.addLayout(fila_botones)
		self.boton_probar.clicked.connect(self._probar_conexion)

		botones = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
		botones.accepted.connect(self._guardar)
		botones.rejected.connect(self.reject)
		layout.addWidget(botones)

	def _motor_actual(self):
		return self.combo_motor.currentData()

	def _actualizar_campos_visibles(self):
		info = ENGINES[self._motor_actual()]
		es_sqlite = info["requiere_archivo"]

		for widget in (self.campo_host, self.campo_puerto, self.campo_usuario,
					   self.campo_password, self.campo_base_datos):
			widget.setVisible(not es_sqlite)
		self.campo_archivo_sqlite.setVisible(es_sqlite)
		self.campo_driver_odbc.setEnabled(self._motor_actual()=="sqlserver")

		if not es_sqlite and (not self.campo_puerto.text() or getattr(self,"_motor_previo",self._motor_actual()) != self._motor_actual()):
			self.campo_puerto.setText(str(info["puerto_default"]))
		self._motor_previo=self._motor_actual()

	def _armar_config(self):
		motor = self._motor_actual()
		info = ENGINES[motor]
		if info["requiere_archivo"]:
			if not self.campo_archivo_sqlite.text().strip():
				QMessageBox.warning(self, "Dato requerido", "Indicá la ruta del archivo SQLite.")
				return None
			return {
				"motor": motor, "host": "", "puerto": None, "usuario": "",
				"password": "", "base_datos": "",
				"archivo_sqlite": self.campo_archivo_sqlite.text().strip(),
			}

		puerto_texto = self.campo_puerto.text().strip()
		if not puerto_texto.isdigit():
			QMessageBox.warning(self, "Dato inválido", "El puerto tiene que ser un número.")
			return None
		return {
			"motor": motor,
			"driver_odbc": self.campo_driver_odbc.text().strip(),
			"host": self.campo_host.text().strip(),
			"puerto": int(puerto_texto),
			"usuario": self.campo_usuario.text().strip(),
			"password": self.campo_password.text(),
			"base_datos": self.campo_base_datos.text().strip(),
			"archivo_sqlite": "",
		}

	def _probar_conexion(self):
		config=self._armar_config()
		if config is None: return
		if hasattr(self,'trabajo') and self.trabajo.esta_ocupado(): return
		self.trabajo=ControladorTrabajo(self)
		self.trabajo.ocupado.connect(lambda ocupado:self.boton_probar.setEnabled(not ocupado))
		self.trabajo.error.connect(lambda mensaje:QMessageBox.warning(self,'Conexión',mensaje))
		self.trabajo.resultado.connect(lambda mensaje:QMessageBox.information(self,'Conexión',mensaje))
		self.trabajo.iniciar(lambda p,c:probar_conexion(config))
	def done(self, resultado):
		if hasattr(self,'trabajo') and self.trabajo.esta_ocupado(): return
		super().done(resultado)
	def closeEvent(self,event):
		if hasattr(self,'trabajo') and self.trabajo.esta_ocupado(): event.ignore()
		else: super().closeEvent(event)
	def _guardar(self):
		config = self._armar_config()
		if config is None:
			return
		try:
			guardar_config_conexion(config)
		except Exception as e:
			QMessageBox.critical(self, "Error al guardar", f"No se pudo guardar la configuración:\n{e}")
			return
		self.accept()

class ConfiguracionTablaEmpleadosDialog(QDialog):
	"""Define en qué tabla/columnas está el nombre de cada empleado, sobre
	la conexión ya configurada."""

	def __init__(self, parent=None):
		super().__init__(parent)
		self.setWindowTitle("Configurar tabla de empleados")
		self.resize(400, 220)

		config_actual = cargar_config_empleados()

		layout = QVBoxLayout(self)
		layout.addWidget(QLabel(
			"Usa la conexión configurada en 'Configurar conexión a base de datos'."
		))
		form = QFormLayout()

		self.campo_tabla = QLineEdit(config_actual.get("tabla", "empleados"))
		self.campo_columna_id = QLineEdit(config_actual.get("columna_id", ""))
		self.campo_columna_id_interno = QLineEdit(config_actual.get("columna_id_interno", "id"))
		self.campo_columna_nombre = QLineEdit(config_actual.get("columna_nombre", ""))
		self.campo_columna_organizacion = QLineEdit(config_actual.get("columna_organizacion", ""))
		self.campo_valor_organizacion = QLineEdit(config_actual.get("valor_organizacion", ""))
		self.campo_columna_organizacion.setPlaceholderText("Ej.: organizacion_id, empresa_id o cliente_id")
		self.campo_valor_organizacion.setPlaceholderText("Ej.: 1")
		self.campo_tabla_organizacion = QLineEdit(config_actual.get("tabla_organizacion", ""))
		self.campo_empleado_organizacion = QLineEdit(config_actual.get("columna_empleado_organizacion", ""))
		self.campo_tabla_organizacion.setPlaceholderText("Ej.: legajo; vacío si está en empleados")
		self.campo_empleado_organizacion.setPlaceholderText("Ej.: empleados_id")
		self.campo_base_catalogo = QLineEdit(config_actual.get("base_catalogo_organizaciones", ""))
		self.campo_tabla_catalogo = QLineEdit(config_actual.get("tabla_catalogo_organizaciones", ""))
		self.campo_id_catalogo = QLineEdit(config_actual.get("columna_id_catalogo", "id"))
		self.campo_nombre_catalogo = QLineEdit(config_actual.get("columna_nombre_catalogo", "nombre"))

		self.destino_unico = QCheckBox('El sistema externo no separa empleados por organización')
		self.destino_unico.setChecked(config_actual.get('modo_organizacion') == 'unica')
		form.addRow(self.destino_unico)
		form.addRow("Tabla:", self.campo_tabla)
		form.addRow("Nombre Columna número tarjeta:", self.campo_columna_id)
		form.addRow("Columna ID interno del empleado:", self.campo_columna_id_interno)
		form.addRow("Nombre Columna apellido/nombre:", self.campo_columna_nombre)
		form.addRow("Columna de organización (opcional):", self.campo_columna_organizacion)
		form.addRow("Valor de organización:", self.campo_valor_organizacion)
		form.addRow("Tabla relacionada (opcional):", self.campo_tabla_organizacion)
		form.addRow("Columna de empleado en esa tabla:", self.campo_empleado_organizacion)
		form.addRow("Base del catálogo (opcional):", self.campo_base_catalogo)
		form.addRow("Tabla del catálogo de organizaciones:", self.campo_tabla_catalogo)
		form.addRow("Columna ID del catálogo:", self.campo_id_catalogo)
		form.addRow("Columna nombre del catálogo:", self.campo_nombre_catalogo)
		form.addRow(QLabel("Dejá los campos de organización vacíos si no usás organizaciones. El filtro se aplica a asistencias y Excel.\nExportá solamente relojes de la organización seleccionada."))
		layout.addLayout(form)

		botones = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
		botones.accepted.connect(self._guardar)
		botones.rejected.connect(self.reject)
		layout.addWidget(botones)

	def _guardar(self):
		tabla = self.campo_tabla.text().strip()
		columna_id = self.campo_columna_id.text().strip()
		columna_id_interno = self.campo_columna_id_interno.text().strip()
		columna_nombre = self.campo_columna_nombre.text().strip()
		columna_organizacion = self.campo_columna_organizacion.text().strip()
		valor_organizacion = self.campo_valor_organizacion.text().strip()
		
		if not tabla or not columna_id or not columna_nombre or not columna_id_interno:
			QMessageBox.warning(self, "Datos requeridos", "Completá tabla, número de tarjeta, ID interno y nombre.")
			return
		try:
			guardar_config_empleados({
				"modo_organizacion": "unica" if self.destino_unico.isChecked() else "catalogo",
				"tabla": tabla,
				"columna_id": columna_id,
				"columna_id_interno": columna_id_interno,
				"columna_nombre": columna_nombre,
				"columna_organizacion": columna_organizacion,
				"valor_organizacion": valor_organizacion,
				"tabla_organizacion": self.campo_tabla_organizacion.text().strip(),
				"columna_empleado_organizacion": self.campo_empleado_organizacion.text().strip(),
				"base_catalogo_organizaciones": self.campo_base_catalogo.text().strip(),
				"tabla_catalogo_organizaciones": self.campo_tabla_catalogo.text().strip(),
				"columna_id_catalogo": self.campo_id_catalogo.text().strip(),
				"columna_nombre_catalogo": self.campo_nombre_catalogo.text().strip()
			})
		except Exception as e:
			QMessageBox.critical(self, "Error al guardar", f"No se pudo guardar:\n{e}")
			return
		self.accept()

class ConfiguracionTablaAsistenciasDialog(QDialog):
	"""Define en qué tabla/columnas del sistema web hay que insertar las
	marcaciones, sobre la conexión ya configurada."""

	def __init__(self, parent=None):
		super().__init__(parent)
		self.setWindowTitle("Configurar tabla de asistencias")
		self.resize(680, 440)

		config_actual = cargar_config_asistencias()

		layout = QVBoxLayout(self)
		layout.addWidget(QLabel(
			"Usa la conexión configurada en 'Configurar conexión a base de datos'."
		))
		form = QFormLayout()

		self.campo_esquema = QLineEdit(config_actual.get('esquema',''))
		self.campo_fecha_hora = QLineEdit(config_actual.get('columna_fecha_hora',''))
		self.campo_eventos = QLineEdit(__import__('json').dumps(config_actual.get('mapa_tipo',{'Entrada':'E','Salida':'S'}),ensure_ascii=False))
		form.addRow('Esquema (opcional):',self.campo_esquema)
		form.addRow('FechaHora combinada (vacío = separadas):',self.campo_fecha_hora)
		form.addRow('Valores por evento (JSON):',self.campo_eventos)
		self.campo_tabla = QLineEdit(config_actual.get("tabla", "asistencias"))
		self.campo_col_empleado = QLineEdit(config_actual.get("columna_empleado", ""))
		self.campo_col_fecha = QLineEdit(config_actual.get("columna_fecha", ""))
		self.campo_col_hora = QLineEdit(config_actual.get("columna_hora", ""))
		self.campo_col_tipo = QLineEdit(config_actual.get("columna_tipo", ""))
		self.campo_col_reloj = QLineEdit(config_actual.get("columna_reloj", ""))
		self.campo_col_c_ver = QLineEdit(config_actual.get("columna_c_ver", ""))

		form.addRow("Tabla:", self.campo_tabla)
		form.addRow("Nombre Columna empleado/Id:", self.campo_col_empleado)
		form.addRow("Nombre Columna fecha:", self.campo_col_fecha)
		form.addRow("Nombre Columna hora:", self.campo_col_hora)
		form.addRow("Tipo de asistencia (opcional):", self.campo_col_tipo)
		form.addRow("Dispositivo (opcional):", self.campo_col_reloj)
		form.addRow("Verificación (opcional):", self.campo_col_c_ver)
		layout.addLayout(form)

		botones = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
		botones.accepted.connect(self._guardar)
		botones.rejected.connect(self.reject)
		layout.addWidget(botones)

	def _guardar(self):
		valores = {
			"tabla": self.campo_tabla.text().strip(),
			"columna_empleado": self.campo_col_empleado.text().strip(),
			"columna_fecha": self.campo_col_fecha.text().strip(),
			"columna_hora": self.campo_col_hora.text().strip(),
			"columna_tipo": self.campo_col_tipo.text().strip(),
			"columna_reloj": self.campo_col_reloj.text().strip(),
			"columna_c_ver": self.campo_col_c_ver.text().strip(),
		}
		valores['esquema']=self.campo_esquema.text().strip()
		valores['columna_fecha_hora']=self.campo_fecha_hora.text().strip()
		try:
			valores['mapa_tipo']=__import__('json').loads(self.campo_eventos.text())
			if not isinstance(valores['mapa_tipo'],dict): raise ValueError()
		except Exception:
			QMessageBox.warning(self,'Eventos','Ingresá un objeto JSON válido para los eventos.'); return
		if not (valores['tabla'] and valores['columna_empleado'] and (valores['columna_fecha_hora'] or (valores['columna_fecha'] and valores['columna_hora']))):
			QMessageBox.warning(self, "Datos requeridos", "Completá todos los campos.")
			return
		try:
			guardar_config_asistencias(valores)
		except Exception as e:
			QMessageBox.critical(self, "Error al guardar", f"No se pudo guardar:\n{e}")
			return
		self.accept()