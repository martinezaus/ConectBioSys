# Configuración migrada a configuracion.db (cifrada).
