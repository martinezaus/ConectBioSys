CONEXION_CONFIG = {
    "motor": 'mysql',
    "host": '192.168.100.40',
    "puerto": 3306,
    "usuario": 'root',
    "password": 'h81m-vg4',
    "base_datos": 'personal',
    "archivo_sqlite": '',
}
