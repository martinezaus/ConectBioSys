from sqlalchemy import text

from resources.config_path import (
	crear_engine_externo, cargar_config_empleados, cargar_config_conexion,
	_validar_identificador_sql, normalizar_config_empleados,
)


def _filtro_organizacion(conexion, config):
	columna = config["columna_organizacion"]
	if not columna or config.get("modo_organizacion") == "unica":
		return "", {}
	quote = conexion.dialect.identifier_preparer.quote
	params = {"organizacion": config["valor_organizacion"]}
	if config["tabla_organizacion"]:
		tabla_relacion = quote(config["tabla_organizacion"])
		fk = quote(config["columna_empleado_organizacion"])
		tabla_empleado = quote(_validar_identificador_sql(config["tabla"]))
		pk = quote(_validar_identificador_sql(config.get("columna_id_interno", "id")))
		return (f"EXISTS (SELECT 1 FROM {tabla_relacion} org_scope "
		        f"WHERE org_scope.{fk} = {tabla_empleado}.{pk} "
		        f"AND org_scope.{quote(columna)} = :organizacion)", params)
	return f"{quote(columna)} = :organizacion", params


def resolver_id_empleado(conexion, numero_reloj, config=None):
	"""Resuelve la tarjeta dentro de la organización configurada, si existe."""
	config = normalizar_config_empleados(cargar_config_empleados() if config is None else config)
	quote = conexion.dialect.identifier_preparer.quote
	tabla = quote(_validar_identificador_sql(config["tabla"]))
	tarjeta = quote(_validar_identificador_sql(config["columna_id"]))
	id_interno = quote(_validar_identificador_sql(config.get("columna_id_interno", "id")))
	filtro, params = _filtro_organizacion(conexion, config)
	where = f"{tarjeta} = :numero_reloj" + (f" AND {filtro}" if filtro else "")
	params["numero_reloj"] = str(numero_reloj).strip()
	ids = conexion.execute(text(f"SELECT {id_interno} FROM {tabla} WHERE {where}"), params).scalars().fetchmany(2)
	contexto = f" ({config['columna_organizacion']}={config['valor_organizacion']})" if filtro else " (sin filtro de organización)"
	if not ids:
		raise ValueError(f"No existe empleado con número de reloj {numero_reloj!r}{contexto}")
	if len(ids) != 1 or ids[0] is None:
		raise ValueError(f"El número de reloj {numero_reloj!r} no identifica un empleado único con ID válido{contexto}")
	return ids[0]


def obtener_mapa_empleados(config=None):
	"""Devuelve tarjeta -> nombre dentro del mismo alcance usado al enviar."""
	config = normalizar_config_empleados(cargar_config_empleados() if config is None else config)
	engine = crear_engine_externo(cargar_config_conexion())
	try:
		with engine.connect() as conexion:
			quote = conexion.dialect.identifier_preparer.quote
			tabla = quote(_validar_identificador_sql(config["tabla"]))
			tarjeta = quote(_validar_identificador_sql(config["columna_id"]))
			nombre = quote(_validar_identificador_sql(config["columna_nombre"]))
			filtro, params = _filtro_organizacion(conexion, config)
			where = f" WHERE {filtro}" if filtro else ""
			resultado = conexion.execute(text(f"SELECT {tarjeta} AS tarjeta, {nombre} AS nombre FROM {tabla}{where}"), params)
			mapa = {}
			for fila in resultado:
				if fila.tarjeta is None:
					continue
				clave = str(fila.tarjeta).strip()
				if clave in mapa:
					raise ValueError(f"Tarjeta {clave!r} repetida en el alcance seleccionado; revisá el filtro de organización.")
				mapa[clave] = fila.nombre
			return mapa
	finally:
		engine.dispose()
