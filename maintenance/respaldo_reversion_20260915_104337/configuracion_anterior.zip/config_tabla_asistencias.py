TABLA_ASISTENCIAS_CONFIG = {
    "tabla": 'asistencias',
    "columna_empleado": 'empleados_id',
    "columna_fecha": 'fecha',
    "columna_hora": 'hora',
    "columna_tipo": 'tipo',
    "columna_reloj": 'reloj',
    "columna_c_ver": 'c_ver',
}
