
from datetime import datetime
from sqlalchemy import MetaData, Table, select, and_
from app.api.empleados import resolver_id_empleado
from app.api.organizaciones import validar_organizacion
from app.licencias import exigir_licencia
from app.perfiles import integracion_habilitada
from resources.config_path import (
	crear_engine_externo,
	cargar_config_asistencias,
	cargar_config_empleados,
	normalizar_config_empleados,
	cargar_config_conexion,
	_validar_identificador_sql,
)

# Traducción de nuestro modelo interno al formato del sistema web.
MAPA_TIPO = {"Entrada": "E", "Salida": "S"}

MAPA_METODO_A_CVER = {
	"huella": 1,
	"rostro": 15,
	"tarjeta": 3,
	"clave": 3,
	"desconocido": 3,
	"sin_clasificar": 3,
	"entrada": 3, "salida": 3, "inicio_pausa": 3,
	"fin_pausa": 3, "entrada_extra": 3, "salida_extra": 3,
}


def _armar_valores(fila):
	"""fila = (dispositivo_id, numero_reloj, fecha_hora_str, tipo_evento_texto, metodo)
	tal como vienen de la tabla de exportación en main.py."""

	dispositivo_id, numero_reloj, fecha_hora_str, tipo_evento_texto, metodo = fila

	dt    = datetime.fromisoformat(str(fecha_hora_str))
	fecha = dt.date()
	hora  = dt.time().replace(tzinfo=None)
	tipo  = MAPA_TIPO.get(tipo_evento_texto)
	if tipo is None: raise ValueError(f"Evento sin mapeo: {tipo_evento_texto}")

	try:
		reloj = int(dispositivo_id)
	except (TypeError, ValueError):
		reloj = None  # el sistema web tendrá que aceptar NULL o filtrarlo

	c_ver = MAPA_METODO_A_CVER.get(str(metodo).lower(), 3)  # 3 = Manual por defecto

	return numero_reloj, fecha, hora, tipo, reloj, c_ver

def enviar_marcaciones(filas, config_empleados=None):
    """Resuelve empleados en su organización e inserta usando los tipos reflejados.
    Una transacción por lote: un fallo SQL revierte todo el lote. Los registros
    inválidos se omiten antes de insertar. Un índice UNIQUE remoto es necesario
    para impedir duplicados entre distintas instalaciones concurrentes.
    """
    exigir_licencia()
    if not integracion_habilitada():
        raise ValueError('La integración está desactivada para este cliente. Usá Excel.')
    config_empleados=normalizar_config_empleados(cargar_config_empleados() if config_empleados is None else config_empleados)
    config=cargar_config_asistencias()
    engine=crear_engine_externo(cargar_config_conexion())
    insertadas=0; errores=0; detalles=[]
    try:
        tabla=Table(_validar_identificador_sql(config['tabla']),MetaData(),schema=config.get('esquema') or None,
                    autoload_with=engine,resolve_fks=False)
        campos={'empleado':'columna_empleado','tipo':'columna_tipo','reloj':'columna_reloj','c_ver':'columna_c_ver'}
        if config.get('columna_fecha_hora'): campos['fecha_hora']='columna_fecha_hora'
        else: campos.update(fecha='columna_fecha',hora='columna_hora')
        mapeo={origen:config.get(clave) for origen,clave in campos.items() if config.get(clave)}
        if 'empleado' not in mapeo or not ('fecha_hora' in mapeo or {'fecha','hora'}<=mapeo.keys()):
            raise ValueError('Falta mapear empleado y fecha/hora.')
        if len(mapeo.values())!=len(set(mapeo.values())): raise ValueError('Una columna de destino está mapeada dos veces.')
        for columna in mapeo.values():
            if columna not in tabla.c: raise ValueError(f'Columna inexistente: {columna}')
        for col in tabla.c:
            if col.name not in mapeo.values() and not col.nullable and col.server_default is None and col.default is None and col is not tabla.autoincrement_column and col.computed is None and col.identity is None:
                raise ValueError(f'Falta mapear la columna obligatoria {col.name}.')
        mapa=config.get('mapa_tipo',MAPA_TIPO)
        with engine.begin() as conexion:
            validar_organizacion(conexion,config_empleados)
            ids={}
            for fila in filas:
                try:
                    dispositivo,tarjeta,fecha_hora,tipo,metodo=fila
                    dt=datetime.fromisoformat(str(fecha_hora)).replace(tzinfo=None)
                    clave=str(tarjeta).strip()
                    if clave not in ids: ids[clave]=resolver_id_empleado(conexion,clave,config_empleados)
                    if 'tipo' in mapeo and tipo not in mapa: raise ValueError(f'Evento sin mapeo: {tipo}')
                    datos=dict(empleado=ids[clave],fecha=dt.date(),hora=dt.time(),fecha_hora=dt,
                               tipo=mapa.get(tipo),reloj=dispositivo,c_ver=MAPA_METODO_A_CVER.get(str(metodo).lower(),3))
                    valores={destino:datos[origen] for origen,destino in mapeo.items()}
                    from sqlalchemy import String
                    for nombre, valor in valores.items():
                        if valor is not None and isinstance(tabla.c[nombre].type,String):
                            valores[nombre]=valor.isoformat() if hasattr(valor,'isoformat') else str(valor)
                    # Convertir números de dispositivo solo si el destino es numérico.
                    if 'reloj' in mapeo:
                        from sqlalchemy import Integer, Numeric
                        col=tabla.c[mapeo['reloj']]
                        if isinstance(col.type,(Integer,Numeric)): valores[col.name]=int(dispositivo)
                except ValueError as exc:
                    errores+=1
                    if len(detalles)<15: detalles.append(f'Tarjeta {fila[1]}: {exc}')
                    continue
                # Detección de reenvío secuencial con la identidad temporal y el empleado resuelto.
                if conexion.execute(select(tabla.c[mapeo['empleado']]).where(and_(*(tabla.c[k]==v for k,v in valores.items()))).limit(1)).first():
                    errores+=1
                    continue
                conexion.execute(tabla.insert(),valores)
                insertadas+=1
    finally: engine.dispose()
    return insertadas,errores,detalles
