import sys
import importlib
import datetime

from PyQt6.QtWidgets import (
	QApplication,
	QMainWindow,
	QWidget,
	QVBoxLayout,
	QPushButton,
	QTextEdit,
	QHBoxLayout,
	QProgressBar,
	QMessageBox,
	QFileDialog,
	QInputDialog,
	QDialog,
	QDialogButtonBox,
	QTableWidget,
	QTableWidgetItem,
	QCheckBox,
	QLabel,
	QFrame,
	QComboBox,
)
from PyQt6.QtGui import QIcon
from PyQt6.QtCore import Qt, QTimer
from openpyxl import Workbook

from app.database.database import Database
from app.trabajos import ControladorTrabajo
from app.filtros import FiltrosMarcaciones
from app.servicios import rango_filtro, descargar, exportar_excel
from resources.config_app import ESTILO_APP
from app.api.relojes import ConfiguracionRelojesDialog, RangoFechasDialog

from resources.config_path import cargar_relojes, crear_adaptador, cargar_config_empleados
from app.selector_organizacion import SelectorOrganizacion
from app.perfiles import cargar_perfiles, perfil_actual, crear_perfil, activar_perfil, integracion_habilitada
from app.dialogos_cliente import PerfilDialog, LicenciaDialog
from app.licencias import estado_licencia, exigir_licencia
from app.api.empleados import obtener_mapa_empleados
from app.api.asistencias import enviar_marcaciones

ENCABEZADOS_MARCACIONES = ["Dispositivo", "Empleado", "Fecha y hora", "Tipo de evento", "Método"]
RELOJES = []


class TablaMarcacionesDialog(QDialog):
	"""Muestra una lista de marcaciones en una tabla con checkboxes para que el
	usuario elija cuáles exportar a Excel."""

	def __init__(self, filas, titulo="Marcaciones", parent=None):
		super().__init__(parent)
		self.setWindowTitle(titulo)
		self.resize(750, 500)
		self.filas = filas

		layout = QVBoxLayout()
		self.setLayout(layout)

		info = QLabel(f"{len(filas)} marcaciones encontradas. Tildá las que querés exportar.")
		layout.addWidget(info)
		try:
			config_empleados = cargar_config_empleados() if integracion_habilitada() else None
		except Exception:
			config_empleados = None
		self.selector_organizacion = SelectorOrganizacion(config_empleados, self)
		layout.addWidget(self.selector_organizacion)

		fila_acciones = QHBoxLayout()
		self.boton_marcar_todo = QPushButton("Marcar todo")
		self.boton_desmarcar_todo = QPushButton("Desmarcar todo")
		fila_acciones.addWidget(self.boton_marcar_todo)
		fila_acciones.addWidget(self.boton_desmarcar_todo)
		fila_acciones.addStretch()
		layout.addLayout(fila_acciones)

		self.tabla = QTableWidget()
		self.tabla.setColumnCount(len(ENCABEZADOS_MARCACIONES) + 1)
		self.tabla.setHorizontalHeaderLabels(["", *ENCABEZADOS_MARCACIONES])
		self.tabla.setRowCount(len(filas))
		self.tabla.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)

		for fila_idx, fila in enumerate(filas):
			checkbox = QCheckBox()
			checkbox.setChecked(True)
			self.tabla.setCellWidget(fila_idx, 0, checkbox)
			for col_idx, valor in enumerate(fila, start=1):
				item = QTableWidgetItem(str(valor))
				self.tabla.setItem(fila_idx, col_idx, item)

		self.tabla.resizeColumnsToContents()
		layout.addWidget(self.tabla)

		self.boton_marcar_todo.clicked.connect(lambda: self._marcar_todo(True))
		self.boton_desmarcar_todo.clicked.connect(lambda: self._marcar_todo(False))

		botones = QDialogButtonBox()
		self.boton_exportar_excel = botones.addButton("Exportar a Excel", QDialogButtonBox.ButtonRole.ActionRole)
		self.boton_enviar_mysql = botones.addButton("Enviar a base de datos", QDialogButtonBox.ButtonRole.ActionRole)
		self.boton_enviar_mysql.hide()
		self.selector_organizacion.seleccion_cambiada.connect(self._actualizar_destino)
		self.boton_cerrar = botones.addButton("Cerrar", QDialogButtonBox.ButtonRole.RejectRole)

		self.destino = None
		self.boton_exportar_excel.clicked.connect(self._elegir_excel)
		self.boton_enviar_mysql.clicked.connect(self._elegir_mysql)
		botones.rejected.connect(self.reject)
		layout.addWidget(botones)

	def _elegir_excel(self):
		self.destino = "excel"
		self.accept()

	def _actualizar_destino(self):
		self.boton_enviar_mysql.setVisible(self.selector_organizacion.configuracion_seleccionada() is not None and estado_licencia()[0])

	def _elegir_mysql(self):
		if self.selector_organizacion.configuracion_seleccionada() is None:
			return
		self.destino = "mysql"
		self.accept()

	def _marcar_todo(self, estado):
		for fila_idx in range(self.tabla.rowCount()):
			checkbox = self.tabla.cellWidget(fila_idx, 0)
			if checkbox is not None:
				checkbox.setChecked(estado)

	def filas_seleccionadas(self):
		"""Devuelve las filas originales (tuplas) cuyo checkbox quedó tildado."""
		seleccionadas = []
		for fila_idx, fila in enumerate(self.filas):
			checkbox = self.tabla.cellWidget(fila_idx, 0)
			if checkbox is not None and checkbox.isChecked():
				seleccionadas.append(fila)
		return seleccionadas

class VentanaPrincipal(QMainWindow):

	def __init__(self):
		super().__init__()

		self._ocupado = False
		self.trabajo = ControladorTrabajo(self)
		self.trabajo.ocupado.connect(self._bloquear_operacion)
		self.trabajo.progreso.connect(self._progreso)
		self.trabajo.resultado.connect(self._resultado_trabajo)
		self.trabajo.error.connect(lambda mensaje: QMessageBox.warning(self, "Operación", mensaje))
		self.db = Database()  # base local del perfil activo
		self.setWindowTitle("ConectBioSync - Descarga de marcaciones de relojes biometricos")
		self.resize(800, 600)

		# Widget principal
		widget = QWidget()
		self.setCentralWidget(widget)

		# Layout
		layout = QVBoxLayout()
		widget.setLayout(layout)
		fila_cliente = QHBoxLayout()
		label_cliente = QLabel('Cliente:')
		label_cliente.setStyleSheet('color: #dce2f0;')
		fila_cliente.addWidget(label_cliente)
		self.combo_cliente = QComboBox()
		fila_cliente.addWidget(self.combo_cliente, 1)
		self.boton_nuevo_cliente = QPushButton('Nuevo cliente')
		self.boton_editar_cliente = QPushButton('Cliente e integración')
		self.boton_licencia = QPushButton('Licencia')
		for boton in (self.boton_nuevo_cliente, self.boton_editar_cliente, self.boton_licencia):
			fila_cliente.addWidget(boton)
		layout.addLayout(fila_cliente)
		self.estado_licencia_label = QLabel()
		self.estado_licencia_label.setWordWrap(True)
		layout.addWidget(self.estado_licencia_label)
		
		
		# Botón
		self.fila_botones = QHBoxLayout()
		self.boton_conectar = QPushButton("Mes Anterior")
		self.boton_conectar1 = QPushButton("Ultimo 7 dias")
		self.boton_conectar2 = QPushButton("Tarjeta")
		self.boton_exportar = QPushButton("Exportar")
		self.boton_configurar_relojes = QPushButton("Configuraciones")

		self.fila_botones.addWidget(self.boton_conectar)
		self.fila_botones.addWidget(self.boton_conectar1)
		self.fila_botones.addWidget(self.boton_conectar2)
		self.fila_botones.addWidget(self.boton_exportar)
		self.fila_botones.addWidget(self.boton_configurar_relojes)
		self.boton_configurar_relojes.setStyleSheet(
			"QPushButton { background-color: #c0392b; color: white; font-weight: bold; }"
			"QPushButton:hover { background-color: #a93226; }"
			"QPushButton:disabled { background-color: #7f8c8d; color: #dcdcdc; }"
		)
		layout.addLayout(self.fila_botones)
		self.filtros = FiltrosMarcaciones(self)
		layout.addWidget(self.filtros)
		self.filtros.consultar.connect(self._consultar_filtro)
		self.barra_progreso = QProgressBar()
		self.barra_progreso.setVisible(False)   # oculta hasta que se necesite
		layout.addWidget(self.barra_progreso)

		# Área de mensajes
		self.area_mensajes = QTextEdit()
		self.area_mensajes.setReadOnly(True)
		layout.addWidget(self.area_mensajes)


		# AGREGAR EL FOOTER AL FINAL DEL LAYOUT
		self.footer = AppFooter()
		layout.addWidget(self.footer)

		# Evento del botón
		self.boton_conectar.clicked.connect(self.conectar)
		self.boton_conectar1.clicked.connect(self.conectar_dias)
		self.boton_conectar2.clicked.connect(self.conectar_tarjeta)
		self.boton_exportar.clicked.connect(self.exportar)
		self.boton_configurar_relojes.clicked.connect(self.abrir_configuracion_relojes)
		self._cargar_clientes()
		self._recargar_relojes()
		self.combo_cliente.currentIndexChanged.connect(self._cambiar_cliente)
		self.boton_nuevo_cliente.clicked.connect(self._nuevo_cliente)
		self.boton_editar_cliente.clicked.connect(self._editar_cliente)
		self.boton_licencia.clicked.connect(self._abrir_licencia)
		self._actualizar_licencia()
		self._timer_licencia = QTimer(self)
		self._timer_licencia.timeout.connect(self._actualizar_licencia)
		self._timer_licencia.start(60000)

	def _cargar_clientes(self):
		registro = cargar_perfiles()
		self.combo_cliente.blockSignals(True)
		self.combo_cliente.clear()
		for p in registro['perfiles']:
			self.combo_cliente.addItem(p['nombre'], p['id'])
		self.combo_cliente.setCurrentIndex(self.combo_cliente.findData(registro['activo']))
		self.combo_cliente.blockSignals(False)

	def _cambiar_cliente(self, index):
		if self._ocupado or index < 0:
			return
		anterior = perfil_actual()['id']
		try:
			activar_perfil(self.combo_cliente.itemData(index))
			self.db = Database()
			self._recargar_relojes()
			self.mostrar_mensaje(f"Cliente activo: {perfil_actual()['nombre']}")
		except Exception as exc:
			activar_perfil(anterior)
			self._cargar_clientes()
			QMessageBox.warning(self, 'Cliente', str(exc))

	def _nuevo_cliente(self):
		nombre, ok = QInputDialog.getText(self, 'Nuevo cliente', 'Nombre de la empresa:')
		if not ok: return
		try:
			identificador = crear_perfil(nombre)
			self._cargar_clientes()
			self.combo_cliente.setCurrentIndex(self.combo_cliente.findData(identificador))
		except Exception as exc:
			QMessageBox.warning(self, 'Cliente', str(exc))

	def _editar_cliente(self):
		if PerfilDialog(self).exec() == QDialog.DialogCode.Accepted:
			self._cargar_clientes()

	def _abrir_licencia(self):
		LicenciaDialog(self).exec()
		self._actualizar_licencia()

	def _actualizar_licencia(self):
		valida, mensaje, payload = estado_licencia()
		self.estado_licencia_label.setText(mensaje)
		self.estado_licencia_label.setStyleSheet('color: #a6e3a1;' if valida else 'color: #f9e2af;')
		for boton in (self.boton_conectar, self.boton_conectar1):
			boton.setEnabled(valida and not self._ocupado)

	def _bloquear_operacion(self, ocupado):
		self._ocupado = ocupado
		self.filtros.setEnabled(not ocupado)
		self.barra_progreso.setVisible(ocupado)
		for widget in (self.combo_cliente, self.boton_nuevo_cliente, self.boton_editar_cliente, self.boton_configurar_relojes, self.boton_exportar, self.boton_conectar2, self.boton_licencia):
			widget.setEnabled(not ocupado)
		self._actualizar_licencia()


	def abrir_configuracion_relojes(self):
		""" Abre la pantalla de administración de relojes. Cada alta, edición o
		baja se guarda al instante dentro de esa pantalla, así que al cerrarla
		(sea como sea que se cierre) recargamos RELOJES en memoria. """
		try:
			dialogo = ConfiguracionRelojesDialog(parent=self)
			dialogo.exec()
		except Exception as exc:
			QMessageBox.warning(self,"Configuración",str(exc))
		self._recargar_relojes()

	def _recargar_relojes(self): 
		global RELOJES
		RELOJES=[]
		try:
			RELOJES = cargar_relojes()
			self.mostrar_mensaje(f"Configuración de relojes actualizada ({len(RELOJES)} relojes).")
		except Exception as e:
			self.mostrar_mensaje(f"No se pudo recargar la configuración de relojes: {e}")

	def conectar(self):
		""" Conecta a los relojes y trae todas las marcaciones del mes anterior """
		desde, hasta = self.rango_mes_anterior()
		self._descargar_marcaciones(desde, hasta, self.boton_conectar)

	def conectar_dias(self):
		""" Conecta a los relojes y trae las marcaciones de los últimos 7 días,
		tomando la fecha de hoy como referencia """
		desde, hasta = self.rango_ultimos_dias(7)
		self._descargar_marcaciones(desde, hasta, self.boton_conectar1)

	def _iniciar(self, operacion, resultado):
		if self._ocupado: return
		self._al_resultado = resultado
		self.barra_progreso.setRange(0, 0)
		self.trabajo.iniciar(operacion)
	def _progreso(self, porcentaje, mensaje):
		self.barra_progreso.setRange(0,100)
		self.barra_progreso.setValue(porcentaje)
		self.mostrar_mensaje(mensaje)
	def _resultado_trabajo(self, resultado):
		self._al_resultado(resultado)
	def closeEvent(self, event):
		if self.trabajo.esta_ocupado():
			QMessageBox.information(self, 'Operación en curso', 'Esperá a que termine la operación antes de cerrar.')
			event.ignore()
		else: event.accept()
	def _consultar_filtro(self, filtro):
		try:
			desde,hasta,tarjeta=rango_filtro(filtro['modo'],filtro['desde'],filtro['hasta'],filtro['tarjeta'])
			if filtro['origen']==0:
				self._descargar_marcaciones(desde,hasta,None,tarjeta)
			else:
				db=self.db
				self._iniciar(lambda p,c: db.obtener_marcaciones_filtradas(desde,hasta,tarjeta),
					lambda filas:self._mostrar_y_exportar(filas,f'Marcaciones {desde} a {hasta}'))
		except Exception as exc: QMessageBox.warning(self,'Filtro',str(exc))
	def _descargar_marcaciones(self, desde, hasta, boton_disparador=None, tarjeta=None):
		try:
			exigir_licencia()
			if not RELOJES: raise ValueError('Configurá al menos un reloj.')
			from copy import deepcopy
			relojes=deepcopy(RELOJES); ruta=self.db.ruta
			self._iniciar(lambda p,c: descargar(relojes,ruta,desde,hasta,tarjeta,p,c),self._descarga_lista)
		except Exception as exc: QMessageBox.warning(self,'Descarga',str(exc))
	def _descarga_lista(self, resultado):
		self.mostrar_mensaje(f"Guardadas: {resultado['guardadas']}. Ya existentes: {resultado['duplicadas']}.")
		for error in resultado['errores']: self.mostrar_mensaje(error)
		if resultado['errores']: QMessageBox.warning(self,'Descarga incompleta','\n'.join(resultado['errores']))
		self._mostrar_y_exportar(resultado['filas'],'Marcaciones descargadas / histórico del rango')
	def conectar_tarjeta(self):
		self.filtros.modo.setCurrentIndex(2)
		self.filtros.tarjeta.setFocus()
	def obtener_marcaciones_por_tarjeta(self, tarjeta, desde, hasta):
		if not hasattr(self.db, "obtener_marcaciones_filtradas"):
			raise NotImplementedError(
				"Falta implementar 'obtener_marcaciones_por_tarjeta' en app/database/database.py"
			)
		return self.db.obtener_marcaciones_filtradas(desde, hasta, tarjeta=tarjeta)

	def obtener_todas_marcaciones(self, desde=None, hasta=None):
		if not hasattr(self.db, "obtener_todas_marcaciones"):
			raise NotImplementedError(
				"Falta implementar 'obtener_todas_marcaciones' en app/database/database.py"
			)
		return self.db.obtener_todas_marcaciones(desde, hasta)


	def exportar(self):
		self.filtros.origen.setCurrentIndex(1)
		self.filtros._consultar()
	def _mostrar_y_exportar(self, filas, titulo):
		"""Abre el diálogo de tabla con checkboxes y, si el usuario confirma,
		exporta a Excel las filas que quedaron tildadas."""

		if not filas:
			QMessageBox.information(self, "Marcaciones", "No hay marcaciones para el filtro seleccionado.")
			return
		dialogo = TablaMarcacionesDialog(filas, titulo, parent=self)
		if dialogo.exec() != QDialog.DialogCode.Accepted:
			self.mostrar_mensaje("Exportación cancelada.")
			return

		seleccionadas = dialogo.filas_seleccionadas()
		if not seleccionadas:
			QMessageBox.information(self, "Exportar", "No seleccionaste ninguna marcación.")
			return
		
		if dialogo.destino == "excel":
			self._exportar_a_excel(seleccionadas, dialogo.selector_organizacion.configuracion_seleccionada())
		elif dialogo.destino == "mysql":
			self._enviar_a_mysql(seleccionadas, dialogo.selector_organizacion.configuracion_seleccionada(), dialogo.selector_organizacion.nombre_seleccionado())

	def _exportar_a_excel(self, seleccionadas, config_empleados=None):
		ruta,_=QFileDialog.getSaveFileName(self,'Guardar Excel','marcaciones.xlsx','Excel (*.xlsx)')
		if not ruta: return
		def operacion(progreso,cancelar):
			mapa={}
			if config_empleados is not None:
				try: mapa=obtener_mapa_empleados(config_empleados)
				except Exception: progreso(0,'No se pudieron consultar los nombres. Se exportan las tarjetas originales.')
			return exportar_excel(seleccionadas,ruta,progreso,cancelar,mapa)
		self._iniciar(operacion,lambda archivo: QMessageBox.information(self,'Excel exportado',archivo))
	def _enviar_a_mysql(self, seleccionadas, config_empleados=None, organizacion=''):
		if config_empleados is None: return
		try: exigir_licencia()
		except Exception as exc:
			QMessageBox.warning(self,'Licencia',str(exc)); return
		if QMessageBox.question(self,'Enviar a base externa',f'¿Enviar {len(seleccionadas)} marcaciones para {organizacion}?',
			QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes: return
		self._iniciar(lambda p,c: enviar_marcaciones(seleccionadas,config_empleados),self._envio_listo)
	def _envio_listo(self, resultado):
		insertadas,errores,detalles=resultado
		for detalle in detalles: self.mostrar_mensaje(detalle)
		QMessageBox.information(self,'Exportación',f'Insertadas: {insertadas}. Omitidas o con error: {errores}.')
	def mostrar_mensaje(self, mensaje):
		self.area_mensajes.append(mensaje)

	def rango_mes_anterior(self):
		"""Devuelve (desde, hasta) como 'YYYY-MM-DD' del mes calendario anterior."""
		hoy = datetime.date.today()
		primer_dia_mes_actual = hoy.replace(day=1)
		ultimo_dia_mes_anterior = primer_dia_mes_actual - datetime.timedelta(days=1)
		primer_dia_mes_anterior = ultimo_dia_mes_anterior.replace(day=1)
		return (
			primer_dia_mes_anterior.strftime("%Y-%m-%d"),
			ultimo_dia_mes_anterior.strftime("%Y-%m-%d"),
		)

	def rango_ultimos_dias(self, dias):
		"""Devuelve (desde, hasta) como 'YYYY-MM-DD' cubriendo los últimos
		'dias' días, tomando la fecha de hoy como referencia (hasta = hoy)."""
		hoy = datetime.date.today()
		desde = hoy - datetime.timedelta(days=dias-1)
		return desde.strftime("%Y-%m-%d"), hoy.strftime("%Y-%m-%d")

class AppFooter(QFrame):
    """Componente de Footer reutilizable"""
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Estilo del Footer (fondo oscuro, bordes y tipografía adaptada)
        self.setStyleSheet("""
            QFrame {
                background-color: #1e1e2e;
                border-top: 1px solid #313244;
                color: #a6adc8;
                font-family: 'Segoe UI', sans-serif;
                font-size: 11px;
            }
            QLabel {
                border: none;
            }
            QPushButton {
                background: transparent;
                border: none;
                color: #89b4fa;
                font-size: 11px;
                padding: 0 4px;
            }
            QPushButton:hover {
                color: #b4befe;
                text-decoration: underline;
            }
        """)

        # Layout principal horizontal
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 6, 12, 6)
        
        # 1. LADO IZQUIERDO: Copyright y Nombre de Empresa
        self.lbl_copyright = QLabel("© 2026 <b>Conetia</b> Software | Todos los derechos reservados")
        layout.addWidget(self.lbl_copyright)

        layout.addStretch()  # Empuja los elementos del centro hacia el medio

        # 2. CENTRO: Licencia y Botón "Acerca de"
        self.btn_license = QPushButton("Licencia Propietaria")
        self.btn_license.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_license.clicked.connect(self.show_license_dialog)

        lbl_separator = QLabel("•")
        lbl_separator.setStyleSheet("color: #45475a;")

        self.btn_about = QPushButton("Acerca de")
        self.btn_about.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_about.clicked.connect(self.show_about_dialog)

        layout.addWidget(self.btn_license)
        layout.addWidget(lbl_separator)
        layout.addWidget(self.btn_about)

        layout.addStretch()  # Empuja los elementos del lado derecho a la esquina

        # 3. LADO DERECHO: Versión y Estado de Conexión
        self.lbl_info = QLabel("v1.0.0  |  <span style='color: #a6e3a1;'>Datos locales</span>")
        layout.addWidget(self.lbl_info)

    # Ventana modal para mostrar la Licencia
    def show_license_dialog(self):
        msg = QMessageBox(self)
        msg.setWindowTitle("Licencia de Uso")
        msg.setText("<b>Términos de Licencia de Uso Propietaria</b>")
        msg.setInformativeText(
            "Este software está protegido por leyes de derecho de autor y tratados internacionales.\n\n"
            "Queda prohibida su copia, redistribución o modificación sin autorización expresa de Conetia Software."
			"Con domicilio legal en la ciudad de Gral Alvear, Mendoza. Contacto telefono: 2625511108"
        )
        msg.setIcon(QMessageBox.Icon.Information)
        msg.exec()

    # Ventana modal "Acerca de"
    def show_about_dialog(self):
        msg = QMessageBox(self)
        msg.setWindowTitle("Acerca de la Aplicación")
        msg.setText("<b>ConectBioSync</b>")
        msg.setInformativeText(
            "Desarrollado por: <b>Conetia Software</b>\n"
            "Soporte: martinez.aus@gmail.com - Telefono: 2625511108\n"
            "Sitio Web: https://www.conetia.com\n\n"
            "© 2026 Conetia. Todos los derechos reservados."
        )
        msg.setIcon(QMessageBox.Icon.Information)
        msg.exec()


if __name__ == "__main__":
	app = QApplication(sys.argv)
	app.setWindowIcon(QIcon("resources/isologo.ico"))
	app.setStyleSheet(ESTILO_APP)
	ventana = VentanaPrincipal()
	ventana.show()
	sys.exit(app.exec())
