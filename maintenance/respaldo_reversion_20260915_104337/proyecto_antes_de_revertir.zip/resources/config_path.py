import re

from resources.marcas_relojes import ADAPTERS
from resources.db_engines import ENGINES
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
from app.perfiles import directorio_perfil

def _leer_config(nombre, archivo, variable, defecto):
    from app.almacen import leer, guardar, importar_literal
    from app.perfiles import perfil_actual
    clave = 'perfil/' + perfil_actual()['id'] + '/' + nombre
    valor = leer(clave)
    if valor is None:
        valor = importar_literal(directorio_perfil() / archivo, variable, defecto)
        guardar(clave, valor)
        ruta = directorio_perfil() / archivo
        if ruta.exists():
            guardar(clave + '/respaldo_original', ruta.read_text(encoding='utf-8-sig'))
            if leer(clave) != valor: raise ValueError('No se pudo verificar la migración.')
            temporal = ruta.with_suffix('.migrando')
            temporal.write_text('# Configuración migrada a configuracion.db (cifrada).\n', encoding='utf-8')
            temporal.replace(ruta)
    return valor


def _guardar_config(nombre, config):
    from app.almacen import guardar
    from app.perfiles import perfil_actual
    guardar('perfil/' + perfil_actual()['id'] + '/' + nombre, config)


def get_config_relojes_path():
    return str(directorio_perfil() / 'config_relojes.py')


def cargar_relojes():
    return _leer_config('relojes','config_relojes.py','RELOJES',[])


def guardar_relojes(relojes):
    _guardar_config('relojes', relojes)


def crear_adaptador(config_reloj):
	"""Instancia el adaptador correcto según el 'tipo' declarado en la config."""

	tipo = config_reloj["tipo"]
	clase = ADAPTERS.get(tipo)
	if clase is None:
		raise ValueError(f"Tipo de reloj desconocido: {tipo!r}")
	return clase(**config_reloj["params"])

# ---------- Conexión externa compartida (empleados + asistencias) ----------

def cargar_config_conexion():
    return _leer_config('conexion','config_conexion.py','CONEXION_CONFIG',
        dict(motor='mysql',host='',puerto=3306,usuario='',password='',base_datos='',archivo_sqlite=''))


def guardar_config_conexion(config):
    _guardar_config('conexion', config)


def crear_engine_externo(config=None):
    config = cargar_config_conexion() if config is None else config
    motor = config['motor']
    if motor not in ENGINES: raise ValueError('Motor de base de datos desconocido.')
    if motor == 'sqlite':
        if not config.get('archivo_sqlite'): raise ValueError('Falta el archivo SQLite.')
        return create_engine(URL.create('sqlite+pysqlite', database=config['archivo_sqlite']), connect_args={'timeout':10})
    if not config.get('host') or not config.get('base_datos'):
        raise ValueError('Completá servidor y base de datos / servicio Oracle.')
    puerto = int(config.get('puerto') or ENGINES[motor]['puerto_default'])
    if not 1 <= puerto <= 65535: raise ValueError('Puerto inválido.')
    query = {}
    database = config['base_datos']
    args = {}
    if motor == 'mysql': args = dict(connect_timeout=10,read_timeout=30,write_timeout=30)
    elif motor == 'postgresql': args = dict(connect_timeout=10,options='-c statement_timeout=30000')
    elif motor == 'sqlserver':
        query = {'driver':config.get('driver_odbc') or 'ODBC Driver 18 for SQL Server','Encrypt':'yes','TrustServerCertificate':'no'}
        args = {'timeout':10}
    elif motor == 'oracle':
        query = {'service_name':config.get('service_name') or database}
        database = None
        args = {'tcp_connect_timeout':10}
    url = URL.create(ENGINES[motor]['url_scheme'],username=config.get('usuario'),password=config.get('password'),
                     host=config['host'],port=puerto,database=database,query=query)
    engine = create_engine(url,connect_args=args,pool_pre_ping=True,hide_parameters=True)
    if motor in ('sqlserver','oracle'):
        from sqlalchemy import event
        @event.listens_for(engine,'connect')
        def limitar(dbapi_connection, connection_record):
            if motor == 'oracle': dbapi_connection.call_timeout=30000
            else: dbapi_connection.timeout=30
    return engine

def probar_conexion(config):
    from sqlalchemy import select, literal
    engine = crear_engine_externo(config)
    try:
        with engine.connect() as conexion: conexion.execute(select(literal(1))).scalar_one()
        return 'Conexión probada correctamente.'
    finally: engine.dispose()

def _validar_identificador_sql(valor):
	"""Rechaza nombres de tabla/columna con caracteres peligrosos (inyección)."""
	if not valor or not valor.replace("_", "").isalnum():
		raise ValueError(f"Nombre de tabla/columna inválido: {valor!r}")
	return valor


# ---------- Mapeo de tabla: EMPLEADOS (lectura) ----------

def normalizar_config_empleados(config):
	"""Migra una igualdad antigua a un filtro parametrizado opcional."""
	config = dict(config)
	config.setdefault("modo_organizacion", "catalogo")
	if config["modo_organizacion"] not in ("catalogo", "unica"):
		raise ValueError("Modo de organización inválido.")
	if "columna_organizacion" not in config and "valor_organizacion" not in config:
		condicion = str(config.get("columna_condicion", "") or "").strip()
		columna, valor = "", ""
		if condicion:
			match = re.fullmatch(r"([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?:'([^']*)'|\"([^\"]*)\"|([+-]?\d+))", condicion)
			if not match:
				raise ValueError("La condición antigua debe ser una igualdad simple, por ejemplo organizacion_id = 1. No se puede omitir ese filtro automáticamente.")
			columna = match.group(1)
			valor = next(v for v in match.groups()[1:] if v is not None)
		config["columna_organizacion"] = columna
		config["valor_organizacion"] = valor
	columna = str(config.get("columna_organizacion", "") or "").strip()
	valor_original = config.get("valor_organizacion", "")
	valor = "" if valor_original is None else str(valor_original).strip()
	if bool(columna) != bool(valor):
		raise ValueError("Completá columna y valor de organización, o dejá ambos vacíos.")
	if columna:
		_validar_identificador_sql(columna)
	tabla_relacion = str(config.get("tabla_organizacion", "") or "").strip()
	columna_relacion = str(config.get("columna_empleado_organizacion", "") or "").strip()
	if bool(tabla_relacion) != bool(columna_relacion):
		raise ValueError("Completá tabla relacionada y columna de empleado, o dejá ambas vacías.")
	if tabla_relacion:
		_validar_identificador_sql(tabla_relacion)
		_validar_identificador_sql(columna_relacion)
		if not columna:
			raise ValueError("La tabla relacionada requiere columna y valor de organización.")
	for clave, defecto in (("base_catalogo_organizaciones", ""), ("tabla_catalogo_organizaciones", ""), ("columna_id_catalogo", "id"), ("columna_nombre_catalogo", "nombre")):
		config[clave] = str(config.get(clave, defecto) or "").strip()
		if config[clave]:
			_validar_identificador_sql(config[clave])
	if config['base_catalogo_organizaciones'] and not config['tabla_catalogo_organizaciones']:
		raise ValueError("Indicá también la tabla del catálogo de organizaciones.")
	if config['tabla_catalogo_organizaciones'] and not (config['columna_id_catalogo'] and config['columna_nombre_catalogo']):
		raise ValueError("Indicá las columnas de ID y nombre del catálogo.")
	config.update(tabla_organizacion=tabla_relacion, columna_empleado_organizacion=columna_relacion)
	config.update(columna_organizacion=columna, valor_organizacion=valor)
	return config


def cargar_config_empleados():
    return normalizar_config_empleados(_leer_config('empleados','config_tabla_empleados.py','TABLA_EMPLEADOS_CONFIG',
        dict(tabla='empleados',columna_id='',columna_id_interno='id',columna_nombre='',columna_organizacion='',valor_organizacion='')))


def guardar_config_empleados(config):
	config = normalizar_config_empleados(config)
	for clave in ("tabla", "columna_id", "columna_nombre"):
		_validar_identificador_sql(config[clave])
	_validar_identificador_sql(config.get("columna_id_interno", "id"))
	config.pop('columna_condicion', None)
	_guardar_config('empleados', config)


def cargar_config_asistencias():
    return _leer_config('asistencias','config_tabla_asistencias.py','TABLA_ASISTENCIAS_CONFIG',
        dict(tabla='asistencias',columna_empleado='',columna_fecha='',columna_hora='',columna_tipo='',columna_reloj='',columna_c_ver=''))


def guardar_config_asistencias(config):
    _validar_identificador_sql(config['tabla'])
    for clave, valor in config.items():
        if (clave.startswith('columna_') or clave == 'esquema') and valor:
            _validar_identificador_sql(valor)
    _guardar_config('asistencias', config)
