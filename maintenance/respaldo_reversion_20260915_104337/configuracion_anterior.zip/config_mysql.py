MYSQL_CONFIG = {
    "host": '192.168.100.40',
    "puerto": 3306,
    "usuario": 'root',
    "password": 'h81m-vg4',
    "base_datos": 'personal',
    "tabla_empleados": 'empleados',
    "columna_id": 'n_reloj',
    "columna_nombre": 'nombre',
}
