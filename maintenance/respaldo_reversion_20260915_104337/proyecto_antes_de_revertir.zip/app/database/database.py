"""Histórico compatible con versiones anteriores. No borra registros al abrir."""
import datetime
import sqlite3
from pathlib import Path
from contextlib import closing
from app.perfiles import ruta_marcaciones

class Database:
    def __init__(self,ruta=None):
        self.ruta=Path(ruta) if ruta is not None else ruta_marcaciones()
        self.ruta.parent.mkdir(parents=True,exist_ok=True)
        self.crear_tablas()
        self._crear_indice_unico()
    def conectar(self):
        return sqlite3.connect(self.ruta,timeout=15)
    def crear_tablas(self):
        with closing(self.conectar()) as conexion,conexion:
            conexion.execute('''CREATE TABLE IF NOT EXISTS marcaciones (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                dispositivo_id TEXT NOT NULL,empleado_id TEXT NOT NULL,
                fecha_hora TEXT NOT NULL,tipo_evento INTEGER,metodo TEXT,
                enviado INTEGER DEFAULT 0,fecha_descarga TEXT)''')
            conexion.execute('CREATE INDEX IF NOT EXISTS idx_marcaciones_fecha ON marcaciones(fecha_hora,empleado_id)')
    def _crear_indice_unico(self):
        with closing(self.conectar()) as conexion,conexion:
            conexion.execute('''CREATE UNIQUE INDEX IF NOT EXISTS idx_marcaciones_unica
                ON marcaciones(dispositivo_id,empleado_id,fecha_hora,tipo_evento)''')
    def obtener_marcaciones_filtradas(self,desde,hasta,tarjeta=None):
        inicio=datetime.date.fromisoformat(str(desde))
        fin=datetime.date.fromisoformat(str(hasta))
        if fin<inicio:raise ValueError('Desde no puede ser posterior a Hasta.')
        limite=fin+datetime.timedelta(days=1)
        sql='''SELECT dispositivo_id,empleado_id,fecha_hora,
            CASE WHEN tipo_evento=0 THEN 'Entrada' WHEN tipo_evento=1 THEN 'Salida'
                 ELSE 'Evento ' || COALESCE(CAST(tipo_evento AS TEXT),'sin clasificar') END,
            metodo FROM marcaciones WHERE fecha_hora>=? AND fecha_hora<?'''
        valores=[inicio.isoformat()+' 00:00:00',limite.isoformat()+' 00:00:00']
        if tarjeta is not None:
            sql+=' AND empleado_id=?';valores.append(str(tarjeta))
        sql+=' ORDER BY fecha_hora'
        with closing(self.conectar()) as conexion:
            return conexion.execute(sql,valores).fetchall()
    def guardar_marcacion(self,dispositivo_id,empleado_id,fecha_hora,tipo_evento,metodo):
        with closing(self.conectar()) as conexion,conexion:
            conexion.execute('''INSERT INTO marcaciones
                (dispositivo_id,empleado_id,fecha_hora,tipo_evento,metodo,fecha_descarga)
                VALUES (?,?,?,?,?,datetime('now'))''',
                (dispositivo_id,empleado_id,fecha_hora,tipo_evento,metodo))
    def obtener_todas_marcaciones(self,desde=None,hasta=None):
        anio=datetime.date.today().year
        return self.obtener_marcaciones_filtradas(desde or f'{anio}-01-01',hasta or f'{anio}-12-31')
